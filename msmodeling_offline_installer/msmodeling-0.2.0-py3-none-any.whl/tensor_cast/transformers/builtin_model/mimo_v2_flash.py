# -------------------------------------------------------------------------
# This file is part of the MindStudio project.
# Copyright (c) 2026 Huawei Technologies Co.,Ltd.
#
# MindStudio is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#
#          http://license.coscl.org.cn/MulanPSL2
#
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
# -------------------------------------------------------------------------

import torch
from transformers import AutoConfig, AutoModel
from transformers.models.auto.configuration_auto import CONFIG_MAPPING

from ..custom_model_registry import ModelProfile, register_model_profile
from .mimo_v2_flash_hf.configuration_mimo_v2_flash import MiMoV2FlashConfig
from .mimo_v2_flash_hf.modeling_mimo_v2_flash import MiMoV2Model


_AUTO_MODEL_ALREADY_REGISTERED_MSG = "already used by a Transformers model"


def _safe_register_mimo_v2_flash_family() -> None:
    model_type = MiMoV2FlashConfig.model_type
    if model_type not in CONFIG_MAPPING:
        AutoConfig.register(model_type, MiMoV2FlashConfig)
    AutoModel.register(MiMoV2FlashConfig, MiMoV2Model, exist_ok=True)


_safe_register_mimo_v2_flash_family()


class MiMoV2MoeExpertMLP(torch.nn.Module):
    def __init__(self, expert_module_list, expert_idx=None):
        super().__init__()
        if expert_idx is not None:
            self.expert = expert_module_list[expert_idx]
        else:
            self.expert = expert_module_list[0]

    def forward(self, hidden_states):
        return self.expert(hidden_states)


register_model_profile(
    ModelProfile(
        model_type="mimo_v2_flash",
        moe_module_name="MiMoV2MoE",
        moe_gate_returns_raw_logits=False,
        moe_num_experts_key="n_routed_experts",
        mtp_block_module_name="MiMoV2DecoderLayer",
        custom_expert_module_type=MiMoV2MoeExpertMLP,
    )
)
