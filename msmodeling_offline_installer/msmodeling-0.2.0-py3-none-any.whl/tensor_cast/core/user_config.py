# -------------------------------------------------------------------------
# This file is part of the MindStudio project.
# Copyright (c) 2026 Huawei Technologies Co.,Ltd.
#
# MindStudio is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#
#          http://license.coscl.org.cn/MulanPSL2
#
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
# -------------------------------------------------------------------------

# _*_coding:utf-8_*_
"""
user_config
"""

import logging
import math
from dataclasses import dataclass, field, fields
from enum import Enum
from typing import List, Optional, Union

from ..core.input_generator import RequestInfo
from ..core.model_source_security import normalize_model_source
from ..core.quantization.config import create_quant_config
from ..core.quantization.datatypes import QuantizeAttentionAction, QuantizeLinearAction
from ..device import DeviceProfile
from ..model_config import (
    ParallelConfig,
    QuantConfig,
    RemoteSource,
    WordEmbeddingTPMode,
)


logger = logging.getLogger(__name__)


class SpeculativeMethod(str, Enum):
    mtp = "mtp"
    dflash = "dflash"
    dspark = "dspark"


@dataclass
class SpeculativeSpec:
    method: Optional[SpeculativeMethod] = None
    num_speculative_tokens: int = 0
    acceptance_length: float = 5.0
    num_draft_layers: int = 0
    draft_model_config_path: Optional[str] = None
    extras: dict = field(default_factory=dict)

    def enabled(self) -> bool:
        return self.method is not None and self.num_speculative_tokens > 0

    def verify_window(self) -> int:
        if not self.enabled():
            return 1
        return self.num_speculative_tokens + 1

    def fold_divisor(self) -> float:
        if not self.enabled():
            return 1.0
        n = self.num_speculative_tokens
        accept = min(max(self.acceptance_length, 0.0), float(n))
        return accept + 1.0


@dataclass
class UserInputConfig:
    device: str = "TEST_DEVICE"
    model_id: str = ""
    num_queries: int = 0
    query_len: int = 0
    context_length: int = 0
    prefix_cache_hit_rate: float = 0.0
    # KV cache offload (Wiki RFC ``rfc_kv_cache_offloading_en.md``). Decode sparse
    # offload moves the device main KV to host; only indexer + a top-k hot
    # buffer stay on device. The sparse window (top-k) is resolved from the
    # model checkpoint config, and the host link bandwidth comes from the
    # DeviceProfile -- neither is user-facing. Defaults keep offload OFF.
    enable_decode_kv_offload: bool = False
    decode_offload_buffer_multiplier: float = 2.0
    decode_offload_hit_rate: float = 0.85
    # Host memory budget for the offload KV pool (GB). 0 disables the host
    # capacity check; when set, candidates whose offloaded KV pool exceeds the
    # budget fail fast instead of returning undeployable results.
    host_memory_available_gb: float = 0.0
    # Prefill layerwise KV offload (Wiki RFC ``rfc_kv_cache_offloading_en.md``). N
    # cache-bearing layers share B physical NPU buffers (round-robin); the rest
    # of the main KV lives on host. B/I are fixed code-level defaults (see
    # ModelRunner._PREFILL_OFFLOAD_*). Defaults keep offload OFF (no change).
    enable_prefill_kv_offload: bool = False
    do_compile: bool = False
    allow_graph_break: bool = False
    dynamic_shapes: bool = False
    dump_input_shapes: bool = False
    dump_op_bound_results: bool = False
    chrome_trace: Optional[str] = None
    graph_log_url: Optional[str] = None
    log_level: Optional[str] = None
    quantize_linear_action: QuantizeLinearAction = QuantizeLinearAction.W8A8_DYNAMIC
    quantize_non_expert_linear_action: QuantizeLinearAction = QuantizeLinearAction.DISABLED
    quantize_lmhead: bool = False
    mxfp4_group_size: int = 32
    quantize_attention_action: QuantizeAttentionAction = QuantizeAttentionAction.DISABLED
    enable_multistream: bool = False
    enable_sequence_parallel: bool = False
    enable_matmul_allreduce: bool = False
    enable_dispatch_ffn_combine: bool = False
    enable_mlapo: bool = False
    decode: bool = False
    num_mtp_tokens: int = 0
    mtp_acceptance_rate: List[float] = field(default_factory=lambda: [0.9, 0.6, 0.4, 0.2])
    speculative_method: Optional[str] = None
    """Draft speculative method: ``dflash``, ``dspark``, or None (disabled)."""
    num_speculative_tokens: int = 0
    """Speculative tokens excluding anchor; internal block_size = n + 1 when n > 0."""
    num_speculative_tokens_explicit: bool = False
    """Whether --num-speculative-tokens was explicitly supplied by the user."""
    acceptance_length: float = 5.0
    """Decode fold scalar (throughput_optimizer); clamped by speculative_method after resolve."""
    num_draft_layers: int = 0
    draft_model_config_path: Optional[str] = None
    dspark_markov_rank: int = 256
    dspark_markov_head: str = "vanilla"
    num_hidden_layers_override: int = 0
    disable_repetition: bool = False
    reserved_memory_gb: float = 0
    """For models with weight > 50GB, the MemoryTracker significantly
    underestimates peak memory. Recommended values:
    - weight < 20GB: 2-5 GB (or leave as 0)
    - weight 20-50GB: 5-10 GB
    - weight > 50GB: 15-20 GB or 20-30% of weight size
    """
    world_size: int = 1
    tp_size: int = 1
    pp_size: int = 1
    dp_size: Optional[int] = None
    pp_layer_partition: Optional[tuple[int, ...]] = None
    """Explicit per-stage layer counts for pipeline parallelism. None uses the
    default balanced partition. Length must equal pp_size and sum to
    num_hidden_layers when set."""
    microbatch_size: int = 1
    """Microbatch size for PP forward pipeline scheduling (Task 4). Ignored when
    pp_size == 1."""
    o_proj_tp_size: Optional[int] = None
    o_proj_dp_size: Optional[int] = None
    mlp_tp_size: Optional[int] = None
    mlp_dp_size: Optional[int] = None
    lmhead_tp_size: Optional[int] = None
    lmhead_dp_size: Optional[int] = None
    ep_size: int = 1
    moe_dp_size: int = 1
    moe_tp_size: Optional[int] = None
    dcp_size: int = 1
    """Decode Context Parallel size. Reuses TP devices (must divide ``tp_size``);
    slices the KV cache along the sequence dimension during decode."""
    word_embedding_tp: Optional[WordEmbeddingTPMode] = None
    enable_redundant_experts: bool = False
    """Pad routing-expert count to a multiple of EP size for load balancing."""
    enable_shared_expert_tp: bool = False
    """Apply tensor-parallelism to shared experts across the EP group.
    Requires expert_parallel_size > 1.
    Mutually exclusive with ``host_external_shared_experts``.
    """
    enable_external_shared_experts: bool = False
    """Allocate dedicated ranks within the EP group to run shared experts."""
    host_external_shared_experts: bool = False
    """Place external shared experts on the host (CPU) side instead of device.
    Mutually exclusive with ``enable_shared_expert_tp``.
    """
    vision_tp_size: int = 1
    block_size: int = 128
    remote_source: str = RemoteSource.huggingface
    image_batch_size: Optional[int] = None
    image_height: Optional[int] = None
    image_width: Optional[int] = None
    performance_model: Union[str, List[str]] = "analytic"
    """Performance model type(s): 'analytic' | 'calibrated' | 'profiling'.
    Can be a single string or a list of strings to run multiple models.
    """
    profiling_database: Optional[str] = None
    """Path to the performance database directory (required for 'profiling' mode)."""
    disable_profiling_interpolation: bool = False
    """Disable InterpolatingDataSource wrapper in profiling mode."""
    analytic_calibration_profile: Optional[str] = None
    """Version-3 SQLite profile used to calibrate the analytic performance model."""
    analytic_calibration_stack: Optional[str] = None
    """Actual software stack for selecting a multi-stack calibration profile; a single-stack profile auto-selects."""

    def __post_init__(self):
        self._normalize_model_source()
        self._validate_device()
        self._validate_vision_parallelism()
        self._normalize_performance_model()
        self._normalize_word_embedding_tp()
        self._validate_pipeline_parallelism()
        self._normalize_draft_method()

    def _normalize_draft_method(self):
        if self.speculative_method is None or self.speculative_method == "":
            self.speculative_method = None
            return
        method = str(self.speculative_method).lower()
        if method not in ("mtp", "dflash", "dspark"):
            raise ValueError(
                f"speculative_method must be 'mtp', 'dflash', 'dspark', or None, got {self.speculative_method!r}"
            )
        self.speculative_method = method
        # New MTP entry uses num_speculative_tokens; model construction still
        # reads num_mtp_tokens (MtpWrapper / ConfigResolver). Bridge so both
        # CLI entries build the same MTP graph.
        if method == "mtp":
            n = int(self.num_speculative_tokens or 0)
            if n > 0 and int(self.num_mtp_tokens or 0) == 0:
                self.num_mtp_tokens = n

    @property
    def dflash(self) -> bool:
        return self.speculative_method == "dflash"

    @property
    def dspark(self) -> bool:
        return self.speculative_method == "dspark"

    @property
    def mtp_new(self) -> bool:
        """True when using the new MTP entry (``--speculative-method mtp``)."""
        return self.speculative_method == "mtp"

    @property
    def speculative(self) -> SpeculativeSpec:
        method_enum: Optional[SpeculativeMethod] = None
        if self.speculative_method is not None:
            try:
                method_enum = SpeculativeMethod(self.speculative_method)
            except ValueError:
                method_enum = None
        return SpeculativeSpec(
            method=method_enum,
            num_speculative_tokens=int(self.num_speculative_tokens or 0),
            acceptance_length=(5.0 if self.acceptance_length is None else float(self.acceptance_length)),
            num_draft_layers=int(self.num_draft_layers or 0),
            draft_model_config_path=self.draft_model_config_path,
            extras={
                "markov_rank": 256 if self.dspark_markov_rank is None else int(self.dspark_markov_rank),
                "markov_head": str(self.dspark_markov_head or "vanilla"),
            },
        )

    def draft_block_size(self) -> int:
        """Draft block length including anchor; 0 when disabled or unresolved."""
        if self.speculative_method is None:
            return 0
        n = int(self.num_speculative_tokens or 0)
        if n <= 0:
            return 0
        return n + 1

    def _normalize_model_source(self):
        source_info = normalize_model_source(self.model_id, self.remote_source)
        self.model_id = source_info.model_id

    def _normalize_performance_model(self):
        """Normalize performance_model to a list of model type strings."""
        pm = self.performance_model
        if pm is None:
            self.performance_model = ["analytic"]
        elif isinstance(pm, str):
            self.performance_model = [pm]
        supported = {"analytic", "calibrated", "profiling"}
        invalid = [name for name in self.performance_model if name not in supported]
        if invalid:
            raise ValueError(f"Unsupported performance model(s): {', '.join(invalid)}")
        if "calibrated" in self.performance_model and not self.analytic_calibration_profile:
            raise ValueError("analytic_calibration_profile is required when using the calibrated performance model")

    def _validate_device(self):
        if self.device not in DeviceProfile.all_device_profiles:
            raise ValueError(f"Device '{self.device}' not recognized.")

    def _validate_vision_parallelism(self):
        if self.vision_tp_size < 1:
            raise ValueError(f"vision_tp_size must be at least 1, got {self.vision_tp_size}")
        if self.vision_tp_size > self.world_size:
            raise ValueError(
                f"vision_tp_size ({self.vision_tp_size}) must not exceed num_devices/world_size ({self.world_size})"
            )
        if self.world_size % self.vision_tp_size != 0:
            raise ValueError(
                f"num_devices/world_size ({self.world_size}) must be divisible by vision_tp_size "
                f"({self.vision_tp_size})"
            )

    def _normalize_word_embedding_tp(self):
        if self.word_embedding_tp is None or self.word_embedding_tp == "":
            self.word_embedding_tp = None
            return
        if isinstance(self.word_embedding_tp, bool):
            self.word_embedding_tp = WordEmbeddingTPMode.col if self.word_embedding_tp else None
            return
        try:
            self.word_embedding_tp = WordEmbeddingTPMode(self.word_embedding_tp)
        except ValueError as err:
            raise ValueError(
                f"word_embedding_tp must be one of {{'col', 'row'}} or None, got {self.word_embedding_tp!r}."
            ) from err

    def _validate_pipeline_parallelism(self):
        if self.pp_layer_partition is not None:
            if len(self.pp_layer_partition) != self.pp_size:
                raise ValueError(
                    f"pp_layer_partition length ({len(self.pp_layer_partition)}) must equal pp_size ({self.pp_size})"
                )
            if any(x < 0 for x in self.pp_layer_partition):
                raise ValueError("pp_layer_partition elements must be non-negative")

    def _print_info(self):
        print("--- Configuration ---")
        print(f"Device: {self.device}")
        print(f"Model ID: {self.model_id}")
        print(f"Number of Queries: {self.num_queries}")
        print(f"Input Length (per query): {self.query_len}")
        print(f"Context Length (per query): {self.context_length}")
        print(f"Is Decode: {self.decode}")
        print(f"Enable repetition: {not self.disable_repetition}")
        if self.num_mtp_tokens > 0:
            print(f"Number of MTP layers: {self.num_mtp_tokens}")
        if self.speculative_method == "mtp":
            n = int(self.num_speculative_tokens or 0)
            block = self.draft_block_size() or "builtin"
            print(
                f"MTP (new entry): enabled={n > 0}, "
                f"num_speculative_tokens={n or 'disabled'}, "
                f"block_size={block}, "
                f"acceptance_length={self.acceptance_length}"
            )
        if self.speculative_method == "dflash":
            block = self.draft_block_size() or "builtin"
            print(
                f"Dflash: enabled=True, "
                f"num_speculative_tokens={self.num_speculative_tokens or 'builtin'}, "
                f"block_size={block}, "
                f"num_draft_layers={self.num_draft_layers or 'builtin'}, "
                f"acceptance_length={self.acceptance_length}"
            )
        if self.speculative_method == "dspark":
            block = self.draft_block_size() or "builtin"
            print(
                f"DSpark: enabled=True, "
                f"num_speculative_tokens={self.num_speculative_tokens or 'builtin'}, "
                f"block_size={block}, "
                f"num_draft_layers={self.num_draft_layers or 'builtin'}, "
                f"acceptance_length={self.acceptance_length}, "
                f"markov_rank={self.dspark_markov_rank}, "
                f"markov_head={self.dspark_markov_head}"
            )
        if self.quantize_linear_action != QuantizeLinearAction.DISABLED:
            print(f"Quantization Linear: {self.quantize_linear_action}, quantize LM Head: {self.quantize_lmhead}")
            if self.quantize_linear_action == QuantizeLinearAction.MXFP4:
                print(f"  MXFP4 group size: {self.mxfp4_group_size}")
        else:
            print("Quantization Linear: Disabled")
        if self.quantize_non_expert_linear_action != QuantizeLinearAction.DISABLED:
            print(f"Quantization Non-Expert Linear (override): {self.quantize_non_expert_linear_action}")
        if self.quantize_attention_action != QuantizeAttentionAction.DISABLED:
            print(f"Quantization Attention: {self.quantize_attention_action}")
        else:
            print("Quantization Attention: Disabled")
        print(f"Use torch.compile: {self.do_compile}")
        if self.do_compile:
            print(f"  allow graph break: {self.allow_graph_break}")
        print(f"Group table averages by input shapes: {self.dump_input_shapes}")
        print(f"Dump operator bound ratios: {self.dump_op_bound_results}")
        if self.chrome_trace:
            print(f"Chrome trace output file: {self.chrome_trace}")
        if "profiling" in self.performance_model:
            status = "Disabled" if self.disable_profiling_interpolation else "Enabled"
            print(f"Profiling interpolation: {status}")
        if self.analytic_calibration_profile:
            if "calibrated" in self.performance_model:
                print("Analytic calibration: Enabled")
                print(f"  profile: {self.analytic_calibration_profile}")
            elif "analytic" in self.performance_model:
                logger.warning(
                    "analytic calibration profile is ignored because the calibrated performance model was not selected"
                )
        if self.image_batch_size:
            print(f"image_batch_size: {self.image_batch_size}")
            print(f"image_height: {self.image_height}")
            print(f"image_width: {self.image_width}")
            print(f"vision_tp_size: {self.vision_tp_size}")
        print("---------------------\n")

    def get_parallel_config(self) -> ParallelConfig:
        return ParallelConfig(
            world_size=self.world_size,
            tensor_parallel_size=self.tp_size,
            data_parallel_size=self.dp_size,
            o_proj_tensor_parallel_size=self.o_proj_tp_size,
            o_proj_data_parallel_size=self.o_proj_dp_size,
            mlp_tensor_parallel_size=self.mlp_tp_size,
            mlp_data_parallel_size=self.mlp_dp_size,
            lmhead_tensor_parallel_size=self.lmhead_tp_size,
            lmhead_data_parallel_size=self.lmhead_dp_size,
            expert_parallel_size=self.ep_size,
            moe_tensor_parallel_size=self.moe_tp_size,
            moe_data_parallel_size=self.moe_dp_size,
            embedding_parallel=self.word_embedding_tp,
            vision_tensor_parallel_size=self.vision_tp_size,
            pipeline_parallel_size=self.pp_size,
            decode_context_parallel_size=self.dcp_size,
        )

    def get_quant_config(self) -> QuantConfig:
        if (
            self.quantize_linear_action == QuantizeLinearAction.DISABLED
            and self.quantize_non_expert_linear_action == QuantizeLinearAction.DISABLED
            and self.quantize_attention_action == QuantizeAttentionAction.DISABLED
        ):
            return QuantConfig()
        extra_kwargs = {}
        linear_actions = [
            self.quantize_linear_action,
            self.quantize_non_expert_linear_action,
        ]
        if QuantizeLinearAction.MXFP4 in linear_actions:
            from ..quantize_utils import QuantGranularity

            extra_kwargs.update(
                weight_group_size=self.mxfp4_group_size,
                weight_quant_granularity=QuantGranularity.PER_GROUP,
            )
        return create_quant_config(
            self.quantize_linear_action,
            quantize_non_expert_linear_action=self.quantize_non_expert_linear_action,
            quantize_lmhead=self.quantize_lmhead,
            quantize_attention_action=self.quantize_attention_action,
            **extra_kwargs,
        )

    def get_request_info(self) -> RequestInfo:
        effective_hit_rate = self.get_effective_prefix_cache_hit_rate()
        cached_prefix_tokens = math.floor(self.query_len * effective_hit_rate)
        effective_query_len = self.query_len - cached_prefix_tokens
        if effective_query_len < 1:
            raise ValueError(
                "Effective query length must be at least 1 after applying prefix cache hit rate. "
                f"Got query_len={self.query_len}, prefix_cache_hit_rate={self.prefix_cache_hit_rate}."
            )
        effective_context_len = self.context_length + cached_prefix_tokens
        return RequestInfo(
            query_len=effective_query_len,
            seq_len=effective_context_len + effective_query_len,
            concurrency=self.num_queries,
            is_decode=self.decode,
            image_batch_size=self.image_batch_size,
            image_height=self.image_height,
            image_width=self.image_width,
            # Keep the invariant seq_len == context_length + query_len so downstream
            # entries (e.g. cache_position / tensor_cast_has_previous_state in
            # generate_inputs) see the cached-prefix tokens as real context.
            context_length=effective_context_len,
        )

    def get_effective_prefix_cache_hit_rate(self, is_decode: Optional[bool] = None):
        if is_decode is None:
            is_decode = self.decode
        if is_decode and self.prefix_cache_hit_rate > 0:
            logger.warning(
                "Ignoring prefix_cache_hit_rate=%.4f in decode mode.",
                self.prefix_cache_hit_rate,
            )
            return 0.0
        return self.prefix_cache_hit_rate

    @classmethod
    def from_args(cls, args) -> "UserInputConfig":
        # get all names of cls
        field_names = {_field.name for _field in fields(cls)}
        logger.debug(
            "Initializing %s from command-line arguments. Class has %d defined fields: %s",
            cls.__name__,
            len(field_names),
            sorted(field_names),
        )

        # Extract only the fields that exist in the cls from args.

        # Handle the special case where the input arguments differ
        # from the command-line arguments by implementing backward compatibility first.
        # input_key:target_key
        special_input_key_map = {
            "compile": "do_compile",
            "compile_allow_graph_break": "allow_graph_break",
            "query_length": "query_len",
            "num_devices": "world_size",
            "profiling_database_path": "profiling_database",
            "chrome_trace_file": "chrome_trace",
        }
        logger.debug(
            "Using special input key mapping for backward compatibility: %s",
            special_input_key_map,
        )
        filtered_kwargs = {}
        for field_name, field_value in vars(args).items():
            if field_name in special_input_key_map:
                filtered_kwargs[special_input_key_map[field_name]] = field_value
            elif field_name in field_names:
                filtered_kwargs[field_name] = field_value

        # Handle --compilation-config: convert the list of feature names into
        # individual boolean fields so that downstream code (e.g. parallel_runner)
        # can read them as usual bool attributes. The set of accepted names is
        # the same as the CLI choices — keep them in sync via the unified
        # ``tensor_cast.core.compilation_config`` module.
        compilation_config = getattr(args, "compilation_config", None)
        if compilation_config:
            from .compilation_config import COMPILATION_CONFIG_OPTIONS

            for flag_name in compilation_config:
                if flag_name in COMPILATION_CONFIG_OPTIONS:
                    filtered_kwargs[flag_name] = True

        return cls(**filtered_kwargs)
